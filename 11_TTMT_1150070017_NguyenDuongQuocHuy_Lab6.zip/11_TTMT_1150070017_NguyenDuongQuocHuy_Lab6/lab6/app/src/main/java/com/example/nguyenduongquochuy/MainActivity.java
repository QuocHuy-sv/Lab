package com.example.nguyenduongquochuy;

import androidx.appcompat.app.AppCompatActivity;

import android.app.ProgressDialog;
import android.os.AsyncTask;
import android.os.Bundle;
import android.widget.Button;
import android.widget.TextView;

import java.lang.ref.WeakReference;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;
import java.util.concurrent.atomic.AtomicInteger;

@SuppressWarnings("deprecation")
public class MainActivity extends AppCompatActivity {

    private TextView tvStatus;
    private Button btnQuick, btnSlow;


    private final AtomicInteger i = new AtomicInteger(0);

    private SlowTask slowTask;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        tvStatus = findViewById(R.id.tvStatus);
        btnQuick = findViewById(R.id.btnQuick);
        btnSlow  = findViewById(R.id.btnSlow);

        btnQuick.setOnClickListener(v -> {
            String now = new SimpleDateFormat("HH:mm:ss dd/MM/yyyy", Locale.getDefault())
                    .format(new Date());
            tvStatus.setText("Status: " + now);
        });

        btnSlow.setOnClickListener(v -> {
            if (slowTask == null || slowTask.getStatus() == AsyncTask.Status.FINISHED) {
                slowTask = new SlowTask(this, i);
                // ví dụ chạy 5 bước (mỗi bước +1 sau 2s). Có thể đổi số bước tùy ý.
                slowTask.execute(5);
            }
        });
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        if (slowTask != null && slowTask.getStatus() != AsyncTask.Status.FINISHED) {
            slowTask.cancel(true);
        }
    }

    private static class SlowTask extends AsyncTask<Integer, Integer, String> {

        private final WeakReference<MainActivity> ref;
        private final AtomicInteger counterRef;
        private ProgressDialog dialog;

        SlowTask(MainActivity activity, AtomicInteger counterRef) {
            this.ref = new WeakReference<>(activity);
            this.counterRef = counterRef;
        }

        @Override
        protected void onPreExecute() {
            MainActivity a = ref.get();
            if (a == null || a.isFinishing()) return;

            // Hiển thị dialog (deprecated) trong thời gian chờ
            dialog = new ProgressDialog(a);
            dialog.setMessage("Running slow job...");
            dialog.setIndeterminate(true);
            dialog.setCancelable(false);
            dialog.show();

            a.btnSlow.setEnabled(false);
        }

        @Override
        protected String doInBackground(Integer... params) {
            int steps = (params != null && params.length > 0) ? params[0] : 5;

            for (int s = 1; s <= steps; s++) {
                if (isCancelled()) break;

                try {
                    Thread.sleep(2000);
                } catch (InterruptedException e) {
                    return "Cancelled";
                }

                // tăng i +1
                int newVal = counterRef.incrementAndGet();

                publishProgress(newVal);
            }
            return "Done";
        }

        @Override
        protected void onProgressUpdate(Integer... values) {
            MainActivity a = ref.get();
            if (a == null || a.isFinishing()) return;

            int current = (values != null && values.length > 0) ? values[0] : a.i.get();
            a.tvStatus.setText("Status: i = " + current + " (updating...)");
        }

        @Override
        protected void onPostExecute(String result) {
            MainActivity a = ref.get();
            if (a == null) return;

            if (dialog != null && dialog.isShowing()) dialog.dismiss();
            a.tvStatus.setText("Status: i = " + a.i.get() + " | " + result);
            a.btnSlow.setEnabled(true);
        }

        @Override
        protected void onCancelled(String result) {
            onCancelled();
        }

        @Override
        protected void onCancelled() {
            MainActivity a = ref.get();
            if (a == null) return;

            if (dialog != null && dialog.isShowing()) dialog.dismiss();
            a.tvStatus.setText("Status: cancelled (i = " + a.i.get() + ")");
            a.btnSlow.setEnabled(true);
        }
    }
}
