package com.example.lab7;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;

import androidx.core.content.ContextCompat;

public class DownloadActionReceiver extends BroadcastReceiver {
    @Override
    public void onReceive(Context context, Intent intent) {
        String action = intent.getAction();
        Intent service = new Intent(context, DownloadService.class);
        if (DownloadService.ACTION_PAUSE.equals(action)) {
            service.setAction(DownloadService.ACTION_PAUSE);
        } else if (DownloadService.ACTION_RESUME.equals(action)) {
            service.setAction(DownloadService.ACTION_RESUME);
        } else if (DownloadService.ACTION_CANCEL.equals(action)) {
            service.setAction(DownloadService.ACTION_CANCEL);
        } else {
            return;
        }
        ContextCompat.startForegroundService(context, service);
    }
}
