package com.example.lab7;

import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.ConnectivityManager;
import android.net.NetworkCapabilities;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts.RequestPermission;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;

public class MainActivity extends AppCompatActivity {

    EditText edtUrl, edtFileName;
    Button btnStart, btnOpenDownloads;
    ActivityResultLauncher<String> notifPermLauncher;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        edtUrl = findViewById(R.id.edtUrl);
        edtFileName = findViewById(R.id.edtFile);
        btnStart = findViewById(R.id.btnStart);
        btnOpenDownloads = findViewById(R.id.btnOpenDownloads);

        // Xin quyền POST_NOTIFICATIONS (Android 13+)
        notifPermLauncher = registerForActivityResult(new RequestPermission(), isGranted -> {});
        if (Build.VERSION.SDK_INT >= 33 &&
                ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS)
                        != PackageManager.PERMISSION_GRANTED) {
            notifPermLauncher.launch(Manifest.permission.POST_NOTIFICATIONS);
        }

        btnStart.setOnClickListener(v -> {
            String url = edtUrl.getText().toString().trim();
            String file = edtFileName.getText().toString().trim();
            if (url.isEmpty() || file.isEmpty()) {
                Toast.makeText(this, "Nhập URL và tên file!", Toast.LENGTH_SHORT).show();
                return;
            }
            if (!isOnline()) {
                Toast.makeText(this, "Không có Internet!", Toast.LENGTH_SHORT).show();
                return;
            }
            Intent i = new Intent(this, DownloadService.class);
            i.setAction(DownloadService.ACTION_START);
            i.putExtra(DownloadService.EXTRA_URL, url);
            i.putExtra(DownloadService.EXTRA_FILE_NAME, file);
            ContextCompat.startForegroundService(this, i);
        });

        btnOpenDownloads.setOnClickListener(v -> {
            // Mở thư mục app external files để xem file tải về
            Uri uri = Uri.parse(getExternalFilesDir(null).toURI().toString());
            Intent intent = new Intent(Intent.ACTION_VIEW);
            intent.setDataAndType(uri, "*/*");
            if (intent.resolveActivity(getPackageManager()) != null) startActivity(intent);
            else Toast.makeText(this, "Không mở được trình duyệt tệp.", Toast.LENGTH_SHORT).show();
        });
    }

    private boolean isOnline() {
        try {
            android.net.ConnectivityManager cm = getSystemService(android.net.ConnectivityManager.class);
            if (cm == null) return false;

            if (android.os.Build.VERSION.SDK_INT >= 23) {
                android.net.Network active = cm.getActiveNetwork();
                if (active == null) return false;
                android.net.NetworkCapabilities caps = cm.getNetworkCapabilities(active);
                return caps != null && (
                        caps.hasTransport(android.net.NetworkCapabilities.TRANSPORT_WIFI) ||
                                caps.hasTransport(android.net.NetworkCapabilities.TRANSPORT_CELLULAR) ||
                                caps.hasTransport(android.net.NetworkCapabilities.TRANSPORT_ETHERNET)
                );
            } else {
                android.net.NetworkInfo ni = cm.getActiveNetworkInfo();
                return ni != null && ni.isConnected();
            }
        } catch (SecurityException se) {
            return false;
        }
    }

}
