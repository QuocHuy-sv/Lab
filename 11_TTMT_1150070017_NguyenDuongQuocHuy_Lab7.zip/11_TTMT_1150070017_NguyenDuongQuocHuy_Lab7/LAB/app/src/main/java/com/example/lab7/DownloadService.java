package com.example.lab7;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Intent;
import android.os.Build;
import android.os.Environment;
import android.os.IBinder;
import android.util.Log;
import android.widget.RemoteViews;

import androidx.annotation.Nullable;
import androidx.core.app.NotificationCompat;

import java.io.BufferedInputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.atomic.AtomicBoolean;

public class DownloadService extends Service {

    public static final String ACTION_START  = "com.example.lab7.action.START";
    public static final String ACTION_PAUSE  = "com.example.lab7.action.PAUSE";
    public static final String ACTION_RESUME = "com.example.lab7.action.RESUME";
    public static final String ACTION_CANCEL = "com.example.lab7.action.CANCEL";

    public static final String EXTRA_URL = "extra.URL";
    public static final String EXTRA_FILE_NAME = "extra.FILE";

    private static final String CHANNEL_ID = "download_channel";
    private static final int NOTIF_ID = 1001;

    private final ExecutorService executor = Executors.newSingleThreadExecutor();
    private final AtomicBoolean isPaused = new AtomicBoolean(false);
    private final AtomicBoolean isCanceled = new AtomicBoolean(false);

    private String urlStr;
    private String fileName;
    private File targetFile;

    private long downloadedBytes = 0L;
    private long totalBytes = -1L;

    @Override public void onCreate() {
        super.onCreate();
        createChannel();
    }

    @Override public int onStartCommand(Intent intent, int flags, int startId) {
        String action = intent != null ? intent.getAction() : null;

        if (ACTION_START.equals(action)) {
            urlStr = intent.getStringExtra(EXTRA_URL);
            fileName = intent.getStringExtra(EXTRA_FILE_NAME);

            if (urlStr == null || urlStr.trim().isEmpty()) {
                Log.e("DownloadService", "URL rỗng → stopSelf()");
                stopSelf();
                return START_NOT_STICKY;
            }
            if (fileName == null || fileName.isEmpty()) fileName = "download.bin";

            targetFile = new File(getExternalFilesDir(Environment.DIRECTORY_DOWNLOADS), fileName);
            isPaused.set(false);
            isCanceled.set(false);

            // MUST: startForeground với notification hợp lệ, bọc SecurityException
            try {
                startForeground(NOTIF_ID, buildNotification(0, 0L, -1L, "Bắt đầu tải...", true));
            } catch (SecurityException se) {
                // Thiếu POST_NOTIFICATIONS hoặc service type → crash nếu không bọc
                Log.e("DownloadService", "startForeground SecurityException: " + se.getMessage());
                stopSelf();
                return START_NOT_STICKY;
            }

            executor.execute(this::downloadLoop);

        } else if (ACTION_PAUSE.equals(action)) {
            isPaused.set(true);
            updateNotification("Đã tạm dừng", progressPercent(), downloadedBytes, totalBytes);

        } else if (ACTION_RESUME.equals(action)) {
            if (isPaused.get()) {
                isPaused.set(false);
                updateNotification("Tiếp tục tải...", progressPercent(), downloadedBytes, totalBytes);
                executor.execute(this::downloadLoop);
            }

        } else if (ACTION_CANCEL.equals(action)) {
            isCanceled.set(true);
            stopSelfSafely(true);
        }

        return START_NOT_STICKY;
    }

    private void downloadLoop() {
        HttpURLConnection conn = null;
        try {
            if (targetFile == null) return;

            downloadedBytes = targetFile.exists() ? targetFile.length() : 0L;

            URL url = new URL(urlStr);
            conn = (HttpURLConnection) url.openConnection();
            conn.setConnectTimeout(15000);
            conn.setReadTimeout(30000);
            if (downloadedBytes > 0) {
                conn.setRequestProperty("Range", "bytes=" + downloadedBytes + "-");
            }
            conn.connect();

            int code = conn.getResponseCode();
            if (!(code == HttpURLConnection.HTTP_OK || code == HttpURLConnection.HTTP_PARTIAL)) {
                updateNotification("Lỗi HTTP: " + code, progressPercent(), downloadedBytes, totalBytes);
                stopSelfSafely(false);
                return;
            }

            long contentLen = conn.getContentLengthLong();
            totalBytes = (downloadedBytes > 0 && code == HttpURLConnection.HTTP_PARTIAL)
                    ? downloadedBytes + contentLen : contentLen;

            try (BufferedInputStream in = new BufferedInputStream(conn.getInputStream());
                 FileOutputStream out = new FileOutputStream(targetFile, downloadedBytes > 0)) {

                byte[] buf = new byte[8192];
                int n;
                long lastUpdate = System.currentTimeMillis();

                while ((n = in.read(buf)) != -1) {
                    if (isCanceled.get()) { stopSelfSafely(true); return; }
                    while (isPaused.get()) {
                        try { Thread.sleep(200); } catch (InterruptedException ignored) {}
                        if (isCanceled.get()) { stopSelfSafely(true); return; }
                    }
                    out.write(buf, 0, n);
                    downloadedBytes += n;

                    long now = System.currentTimeMillis();
                    if (now - lastUpdate > 500) {
                        updateNotification("Đang tải...", progressPercent(), downloadedBytes, totalBytes);
                        lastUpdate = now;
                    }
                }

                updateNotification("Hoàn tất", 100, downloadedBytes, totalBytes);
                stopForeground(false); // hiển thị thông báo hoàn tất
                stopSelf();
            }
        } catch (Exception e) {
            Log.e("DownloadService", "downloadLoop error: ", e);
            updateNotification("Lỗi: " + e.getMessage(), progressPercent(), downloadedBytes, totalBytes);
            stopSelfSafely(false);
        } finally {
            if (conn != null) conn.disconnect();
        }
    }

    private void stopSelfSafely(boolean deleteFile) {
        try {
            if (deleteFile && targetFile != null && targetFile.exists()) targetFile.delete();
        } catch (Exception ignored) {}
        try { stopForeground(true); } catch (Exception ignored) {}
        stopSelf();
    }

    private int progressPercent() {
        if (totalBytes <= 0) return 0;
        long pct = (downloadedBytes * 100L) / totalBytes;
        return (int) Math.max(0, Math.min(100, pct));
    }

    private Notification buildNotification(int progress, long done, long total, String status, boolean ongoing) {
        RemoteViews content = new RemoteViews(getPackageName(), R.layout.notification_download);
        content.setTextViewText(R.id.tvTitle, getString(R.string.notif_title));
        content.setProgressBar(R.id.progressBar, 100, progress, false);

        String sizeText = renderSize(done, total) + " • " + status;
        content.setTextViewText(R.id.tvStatus, sizeText);

        content.setOnClickPendingIntent(R.id.btnPause, makeBroadcastPI(ACTION_PAUSE));
        content.setOnClickPendingIntent(R.id.btnResume, makeBroadcastPI(ACTION_RESUME));
        content.setOnClickPendingIntent(R.id.btnCancel, makeBroadcastPI(ACTION_CANCEL));

        PendingIntent contentPI = PendingIntent.getActivity(
                this, 10, new Intent(this, MainActivity.class),
                PendingIntent.FLAG_UPDATE_CURRENT | (Build.VERSION.SDK_INT >= 23 ? PendingIntent.FLAG_IMMUTABLE : 0));

        return new NotificationCompat.Builder(this, CHANNEL_ID)
                .setSmallIcon(R.drawable.ic_download)
                .setOngoing(ongoing)
                .setOnlyAlertOnce(true)
                .setCustomContentView(content)
                .setContentIntent(contentPI)
                .setPriority(NotificationCompat.PRIORITY_LOW)
                .build();
    }

    private void updateNotification(String status, int progress, long done, long total) {
        boolean ongoing = !(status.startsWith("Hoàn tất") || status.startsWith("Lỗi"));
        Notification n = buildNotification(progress, done, total, status, ongoing);
        NotificationManager nm = getSystemService(NotificationManager.class);
        if (nm != null) nm.notify(NOTIF_ID, n);
    }

    private PendingIntent makeBroadcastPI(String action) {
        Intent i = new Intent(this, DownloadActionReceiver.class).setAction(action);
        return PendingIntent.getBroadcast(
                this, action.hashCode(), i,
                PendingIntent.FLAG_UPDATE_CURRENT | (Build.VERSION.SDK_INT >= 23 ? PendingIntent.FLAG_IMMUTABLE : 0));
    }

    private void createChannel() {
        if (Build.VERSION.SDK_INT >= 26) {
            NotificationChannel ch = new NotificationChannel(
                    CHANNEL_ID, getString(R.string.channel_name),
                    NotificationManager.IMPORTANCE_LOW
            );
            ch.setDescription(getString(R.string.channel_desc));
            NotificationManager nm = getSystemService(NotificationManager.class);
            if (nm != null) nm.createNotificationChannel(ch);
        }
    }

    private String renderSize(long done, long total) {
        String d = humanMB(done);
        String t = total > 0 ? humanMB(total) : "?";
        int pct = total > 0 ? (int)((done * 100L) / total) : 0;
        return pct + "% • " + d + " / " + t + " MB";
    }

    private String humanMB(long bytes) {
        double mb = bytes / 1024d / 1024d;
        return String.format(java.util.Locale.US, "%.2f", mb);
    }

    @Nullable @Override public IBinder onBind(Intent intent) { return null; }
}
